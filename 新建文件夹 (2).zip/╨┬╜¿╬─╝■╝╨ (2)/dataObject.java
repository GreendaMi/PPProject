package com.allrun.arsmartelevatorformanager.widget;

/**
 * 用于封装PPchart表格数据
 * List<dataObject> data = new ArrayList<>();
 * data.add(new dataObject("3.1-7",80f));
 * Created by Administrator on 2017/4/5.
 */

public class dataObject {
    String happenTime;
    int num;

    public dataObject(String happenTime, int num) {
        this.happenTime = happenTime;
        this.num = num;
    }

    public String getHappenTime() {
        return happenTime;
    }

    public void setHappenTime(String happenTime) {
        this.happenTime = happenTime;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }
}
