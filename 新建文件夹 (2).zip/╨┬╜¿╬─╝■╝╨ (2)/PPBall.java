package com.allrun.arsmartelevatorformanager.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import com.allrun.arsmartelevatorformanager.R;

/**
 * Created by zhaopy on 2017/4/11.
 */

public class PPBall extends View {

    Paint mPaint = new Paint();
    public void setColor(int mColor) {
        this.mColor = mColor;
        invalidate();
    }

    int mColor;

    public PPBall(Context context) {
        super(context);
    }

    public PPBall(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        TypedArray b = context.obtainStyledAttributes(attrs, R.styleable.PPBall);
        mColor = b.getColor(R.styleable.PPBall_color, context.getResources().getColor(R.color.colorPrimary));
        b.recycle();
        initPaint();
    }

    private void initPaint() {
        mPaint.setColor(mColor);
        mPaint.setAntiAlias(true);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int widthSpecSize = View.MeasureSpec.getSize(widthMeasureSpec);
        int heightSpecSize = View.MeasureSpec.getSize(heightMeasureSpec);
        int mLayoutSize = Math.min(widthSpecSize, heightSpecSize);
        setMeasuredDimension(mLayoutSize, mLayoutSize);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawCircle(getWidth()/2,getWidth()/2,getWidth()/2,mPaint);
    }
}
