package com.allrun.arsmartelevatorformanager.widget;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.allrun.arsmartelevatorformanager.R;


/**
 * Created by GreendaMi on 2017/2/21.
 */

public class LoadingDialog extends Dialog {
    public LoadingDialog(Context context) {
        super(context, R.style.Theme_Dialog_Transparent);
        /**设置对话框背景透明*/
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        setContentView(R.layout.loading);
        setCanceledOnTouchOutside(false);
    }

    public LoadingDialog(Context context, String msg){
        super(context, R.style.Theme_Dialog_Transparent);
        /**设置对话框背景透明*/
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        setCanceledOnTouchOutside(false);
        View view = LayoutInflater.from(context).inflate(R.layout.loading_with_text, null);
        setContentView(view);
        tvMsg = (TextView) view.findViewById(R.id.tv_msg);
    }

    public static LoadingDialog mLoadingDialog;

    public static LoadingDialog mLoadingWithTextDialog;
    private static TextView tvMsg;

    public static void ShowDialog(Context context){
        if(mLoadingDialog == null && context == null){
            return;
        }
        if(mLoadingDialog == null){
            mLoadingDialog = new LoadingDialog(context);
        }
        mLoadingDialog.show();
    }

    public static void DismissDialog(){
        if(mLoadingDialog != null){
            mLoadingDialog.dismiss();
            mLoadingDialog = null;
        }

    }

    public static void showHaveTextDialog(Context context, String msg){
        if(mLoadingWithTextDialog == null && context == null){
            return;
        }
        if(mLoadingWithTextDialog == null){
            mLoadingWithTextDialog = new LoadingDialog(context, msg);
        }
        tvMsg.setText(msg);
        mLoadingWithTextDialog.show();
    }

    public static void dissmissHaveTextDialog(){
        if(mLoadingWithTextDialog != null){
            mLoadingWithTextDialog.dismiss();
            mLoadingWithTextDialog = null;
        }
    }
}
