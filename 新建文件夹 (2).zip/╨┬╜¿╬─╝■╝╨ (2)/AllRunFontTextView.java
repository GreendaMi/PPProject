package com.allrun.arsmartelevatorformanager.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;

/**
 * Created by zhaopy on 2017/5/8.
 */

public class AllRunFontTextView extends android.support.v7.widget.AppCompatTextView {
        Context context;

    public AllRunFontTextView(Context context) {
            super(context);
        }

    public AllRunFontTextView(Context context, AttributeSet attrs) {
            super(context, attrs);
            this.context = context;
            Typeface typeface = Typeface.createFromAsset(context.getAssets(), "iconfont/AL.ttf");
            setTypeface(typeface);
    }
}
