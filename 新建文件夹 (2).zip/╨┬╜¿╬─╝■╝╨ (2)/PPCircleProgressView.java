package com.allrun.arsmartelevatorformanager.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;

import com.allrun.arsmartelevatorformanager.R;
import com.allrun.arsmartelevatorformanager.util.DPUnitUtil;

/**
 * 圆形进度条
 * Created by zhaopy on 2017/3/1.
 */

public class PPCircleProgressView extends View {

    private float progress = 100; //显示的进度
    private String strprogress = "100"; //显示的进度
    private int mLayoutSize = 100;//整个控件的尺寸（方形）
    public int mColor;//主要颜色
    public int mColorBackground;
    Typeface typeface_number;

    Context mContext;

    private float now = 0; //当前的进度

    public PPCircleProgressView(Context context) {
        super(context);
        mContext = context;
    }

    public PPCircleProgressView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        mColor = context.getResources().getColor(R.color.colorPrimary);
        mColorBackground = context.getResources().getColor(R.color.white);
        typeface_number = Typeface.createFromAsset(context.getAssets(), "iconfont/number.ttc");
    }

    public PPCircleProgressView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int widthSpecSize = MeasureSpec.getSize(widthMeasureSpec);
        int heightSpecSize = MeasureSpec.getSize(heightMeasureSpec);

        mLayoutSize = Math.min(widthSpecSize, heightSpecSize);
        if (mLayoutSize == 0) {
            mLayoutSize = Math.max(widthSpecSize, heightSpecSize);
        }
        setMeasuredDimension(mLayoutSize, mLayoutSize);


    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(mContext.getResources().getColor(R.color.dark_background));
        paint.setStyle(Paint.Style.FILL); //设置空心

        //画灰线
        int centre = getWidth() / 2; //获取圆心的x坐标
        float radius = centre; //圆环的半径
        canvas.drawCircle(centre, centre, radius, paint); //画出圆环

        //画扇形
//        if(now < 60){
//            paint.setColor(mContext.getResources().getColor(R.color.colorPrimaryRed));
//        }else{
            paint.setColor(mColor);
//        }
        RectF rectF = new RectF(0, 0, mLayoutSize, mLayoutSize);

        //5度一个格子，防止占半个格子
        int endR = (int)(360 * (now / 100) / 5) * 5;
        canvas.drawArc(rectF, -90, endR, true, paint);

        //画白圆
        paint.setColor(Color.WHITE);
        paint.setStyle(Paint.Style.FILL); //设置空心
        radius = radius * 0.8f; //圆环的半径
        canvas.drawCircle(centre, centre, radius, paint); //画出圆环

        //画线，许多的线，5度画一条
        paint.setStrokeWidth(DPUnitUtil.dip2px(mContext,2));

        for(int r = 0;r < 360;r = r + 5){
            canvas.drawLine(centre + (float)(centre * Math.sin(Math.toRadians(r))),
                    centre - (float)(centre * Math.cos(Math.toRadians(r))),
                    centre - (float)(centre * Math.sin(Math.toRadians(r))),
                    centre + (float)(centre * Math.cos(Math.toRadians(r))),paint);
        }


        //到此，背景绘制完毕

        String per = (int)now + "";

        //写百分比
        if ("".equals(strprogress)) {
            paint.setColor(mContext.getResources().getColor(R.color.dark_text));
            paint.setStrokeWidth(DPUnitUtil.dip2px(mContext,2));
            canvas.drawLine(centre * 0.77f, centre, centre * 0.95f, centre, paint);
            canvas.drawLine(centre * 1.05f, centre, centre * 1.23f, centre, paint);
        } else {
            paint.setColor(mContext.getResources().getColor(R.color.dark_text));
            paint.setTextSize(mLayoutSize / 4.5f);//控制文字大小
            paint.setTypeface(typeface_number);
            Paint paint2 = new Paint();
            paint2.setAntiAlias(true);
            paint2.setTextSize(mLayoutSize / 12);//控制文字大小
            paint2.setTypeface(typeface_number);
            paint2.setColor(mContext.getResources().getColor(R.color.normal_text));
            canvas.drawText(per,
                    centre - 0.5f * (paint.measureText(per) + paint2.measureText("%")),
                    centre - 0.8f * (paint.ascent() + paint.descent()),
                    paint);
            canvas.drawText("%",
                    centre - 0.5f * (paint.measureText(per) + paint2.measureText("%")) + paint.measureText((int)now + ""),
                    centre + 0.2f * (paint.ascent() + paint.descent()),
                    paint2);

        }

        if (now < progress - 1) {
            now = now + 1;
            postInvalidate();
        } else if (now < progress) {
            now = (int)progress;
            postInvalidate();
        }
    }


    /**
     * 外部回调
     *
     * @param strprogress 显示调进度文字，如果是""，或者努力了，则显示两条横线
     * @param progress    进度条调进度
     * @param isAnim      进度条是否需要动画
     */
    public void setProgress(String strprogress, float progress, boolean isAnim) {
        if (strprogress == null) {
            this.strprogress = "";
        } else {
            this.strprogress = strprogress;
        }
        this.now = 0;
        this.progress = progress;


        if (!isAnim) {
            now = progress;
        }
        postInvalidate();
    }


}