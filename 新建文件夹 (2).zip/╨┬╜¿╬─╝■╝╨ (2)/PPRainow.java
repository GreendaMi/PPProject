package com.allrun.arsmartelevatorformanager.widget;


import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import com.allrun.arsmartelevatorformanager.R;

import java.util.ArrayList;
import java.util.List;

/**
 * 彩虹门
 * Created by zhaopy on 2017/4/12.
 */

public class PPRainow extends View {

    Context mContext;
    List<Float> mData = new ArrayList<Float>();//数据
    List<Integer> mColors = new ArrayList<Integer>();//数据对应的颜色
    Paint mPaint = new Paint();
    float offset = 0.3f;//圆心，对于整个视图的偏移量
    float strcount = 0f;
    String title = "";

    public PPRainow(Context context) {
        super(context);
        mContext = context;
    }

    public PPRainow(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        TypedArray b = context.obtainStyledAttributes(attrs, R.styleable.PPRainow);
        title = b.getString(R.styleable.PPRainow_title);
        b.recycle();
        initPaint();
    }

    private void initPaint() {
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
    }

    public void setData(List<Float> mData, List<Integer> mColors) {
        this.mData = mData;
        this.mColors = mColors;
        //计算总数，用于显示
        strcount = 0;
        for(float  temp :mData){
            strcount += temp;
        }
        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int widthSpecSize = MeasureSpec.getSize(widthMeasureSpec);

        //xml中的layout_height不起作用，高度为宽度的0.681
        setMeasuredDimension(widthSpecSize, (int)(widthSpecSize * 0.681f));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mData.size() == 0) {
            return;
        }
        offset = 1f - (getHeight() + 0.0f)/getWidth();

        //内心圆的半径
        float r = getWidth()* 0.78f  / 2;

        float total = 0;
        for (float temp : mData) {
            total = total + temp;
        }

        RectF rf = new RectF(0f, 0f, getWidth(), getWidth());
        //底部被占用掉的角度的一半
        float disappearAngle = (float) Math.toDegrees(Math.acos((getWidth()/2-getWidth()*offset)/r ));
        float startAngle = -270f + disappearAngle;//起点
        int i = 0;


        for (float temp : mData) {
            mPaint.setColor(mColors.get(i));
            i++;
            float sweepAngle = temp * (360 - 2 * disappearAngle) / total;
            if(temp == 0){
                continue;
            }
            canvas.drawArc(rf, startAngle, sweepAngle, true, mPaint);
            startAngle += sweepAngle;

        }

        //画内心圆
        mPaint.setColor(0xffffffff);
        canvas.drawCircle(getWidth() / 2, getWidth() / 2 ,r, mPaint);

        //写文字
        mPaint.setColor(0xff333333);
        mPaint.setTextSize(getWidth()/6);
        canvas.drawText((int)strcount +"",(getWidth()- mPaint.measureText((int)strcount + ""))/2 ,getWidth()/2 - mPaint.getFontMetrics().bottom,mPaint);

        mPaint.setColor(0xff999999);
        mPaint.setTextSize(getWidth()/18);
        canvas.drawText(title,(getWidth()- mPaint.measureText(title))/2,getWidth() /2 + mPaint.getFontMetrics().bottom * 2 + mPaint.descent() * 2,mPaint);
    }
}
