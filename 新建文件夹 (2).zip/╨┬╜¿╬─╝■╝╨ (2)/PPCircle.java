package com.allrun.arsmartelevatorformanager.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by zhaopy on 2017/4/11.
 */

public class PPCircle extends View {
    Context mContext;

    List<Float> mData = new ArrayList<Float>();//数据
    List<Integer> mColors = new ArrayList<Integer>();//数据对应的颜色
    Paint mPaint = new Paint();
    int animAngle = 360;

    public PPCircle(Context context) {
        super(context);
    }

    public PPCircle(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        initPaint();
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private void initPaint() {
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
    }


    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int widthSpecSize = View.MeasureSpec.getSize(widthMeasureSpec);
        int heightSpecSize = View.MeasureSpec.getSize(heightMeasureSpec);
        int mLayoutSize = Math.min(widthSpecSize, heightSpecSize);
        setMeasuredDimension(mLayoutSize, mLayoutSize);
    }

    public void setData(List<Float> mData, List<Integer> mColors) {
        this.mData = mData;
        this.mColors = mColors;
        animAngle = 360;
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mData.size() == 0) {
            return;
        }

        //切掉圆心
//        Path mPath  =new  Path();
//        mPath.addCircle(getWidth()/2,getWidth()/2,getWidth()/2* 0.4f ,Path.Direction.CW);
//        canvas.clipPath(mPath, Region.Op.XOR);

        float total = 0;
        for (float temp : mData) {
            total = total + temp;
        }

        RectF rf = new RectF(1f, 1f, getWidth()-1, getHeight()-1);
        float startAngle = -90f;//起点
        int i = 0;

        for (float temp : mData) {
            mPaint.setColor(mColors.get(i));
            float sweepAngle = temp * 360 / total;
            canvas.drawArc(rf, startAngle, sweepAngle, true, mPaint);
            startAngle += sweepAngle;
            i++;
        }

        //初始动画
        rf = new RectF(0f, 0f, getWidth(), getHeight());
        mPaint.setColor(0xfff6f6f6);
        if (animAngle > 0) {
            canvas.drawArc(rf, startAngle, animAngle, true, mPaint);
            //初始动画速度
            animAngle = animAngle - 6;
        }
        //中间圆环
        mPaint.setColor(0xfff6f6f6);
        canvas.drawCircle(getWidth() / 2, getWidth() / 2, getWidth() / 2 * 0.4f, mPaint);

        //是否进行初始动画
        if (animAngle >= 0) {
            postInvalidate();
        }
    }
}
