package com.allrun.arsmartelevatorformanager.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import com.allrun.arsmartelevatorformanager.R;
import com.allrun.arsmartelevatorformanager.util.DPUnitUtil;

/**
 * Created by Administrator on 2017/3/23.
 */

public class PPCheckBoxWithoutText extends View {

    Context mContext;
    public int mColor;
    public int whiteColor;
    public Paint mPaint = new Paint();
    onPPCheckBoxChangeListener monPPCheckBoxChangeListener;

    float border;

    public boolean isChecked() {
        return isChecked;
    }

    boolean isChecked = false;
    boolean isMoving = false;//滑块是否在移动
    boolean isEnable = true;

    float satrtX = 0;//滑块在最左边时的X轴坐标
    float endX = 0;//滑块在最右边时的X轴坐标

    float X = 0;//滑块的实时坐标

    public PPCheckBoxWithoutText(Context context) {
        super(context);
        mContext = context;
        mColor = context.getResources().getColor(R.color.colorPrimary);
        whiteColor = context.getResources().getColor(R.color.white);
        init();
    }

    public PPCheckBoxWithoutText(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        mColor = context.getResources().getColor(R.color.colorPrimary);
        whiteColor = context.getResources().getColor(R.color.white);
        init();
    }

    private void init() {
        border = DPUnitUtil.dip2px(mContext, 2);
        mPaint.setAntiAlias(true);
        setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isEnable){
                    return;
                }
                isChecked = !isChecked;
                if (monPPCheckBoxChangeListener != null) {
                    monPPCheckBoxChangeListener.onChange(isChecked);
                }
                postInvalidate();
            }
        });
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);

        //画背景
        if(isChecked){
            mPaint.setColor(mColor);
        }else{
            mPaint.setColor(mContext.getResources().getColor(R.color.color5));
        }

        RectF backgroundRect = new RectF(0, 0, getWidth(), getHeight());
        canvas.drawRoundRect(backgroundRect, DPUnitUtil.dip2px(mContext, 3), DPUnitUtil.dip2px(mContext, 3), mPaint);

        //画写文字
//        mPaint.setColor(whiteColor);
//        mPaint.setTextSize(getHeight() / 2.5f);//控制文字大小
//        canvas.drawText("123",
//                getWidth() / 4 - 0.5f * mPaint.measureText("123"),
//                getHeight() / 2 - 0.6f * (mPaint.ascent() + mPaint.descent()),
//                mPaint);
//
//        canvas.drawText("***",
//                getWidth() * 3 / 4 - 0.5f * mPaint.measureText("***"),
//                getHeight() / 2 - 0.8f * (mPaint.ascent() + mPaint.descent()),
//                mPaint);

        //画遮挡按钮
        mPaint.setColor(whiteColor);
        satrtX = border;
        endX = getWidth() / 2 - border;


        if (isChecked && !isMoving) {
            X = satrtX;
        }
        if (!isChecked && !isMoving) {
            X = endX;
        }
        backgroundRect = new RectF(X, border, X + getWidth() / 2, getHeight() - border);
        canvas.drawRoundRect(backgroundRect, DPUnitUtil.dip2px(mContext, 3), DPUnitUtil.dip2px(mContext, 3), mPaint);
    }


//    @Override
//    public boolean onTouchEvent(MotionEvent event) {
//        switch (event.getAction()) {
//            case MotionEvent.ACTION_DOWN:
//                border = DPUnitUtil.dip2px(mContext, 4);
//                postInvalidate();
//                break;
//
//            case MotionEvent.ACTION_MOVE:
//                float x = event.getX();
//                if (x > endX) {
//                    isMoving = false;
//                    setChecked(false);
//                } else if (x < satrtX) {
//                    isMoving = false;
//                    setChecked(true);
//                } else {
//                    X = x;
//                    isMoving = true;
//                    postInvalidate();
//                }
//                break;
//
//            case MotionEvent.ACTION_UP:
//                border = DPUnitUtil.dip2px(mContext, 2);
//                x = event.getX();
//                if (x > (endX + satrtX) / 2) {
//                    isMoving = false;
//                    setChecked(false);
//                } else {
//                    isMoving = false;
//                    setChecked(true);
//                }
//                postInvalidate();
//                break;
//        }
//        return super.onTouchEvent(event);
//    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnable){
            return true;
        }
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                border = DPUnitUtil.dip2px(mContext, 4);
                postInvalidate();
                break;


            case MotionEvent.ACTION_UP:
                border = DPUnitUtil.dip2px(mContext, 2);
                postInvalidate();
                break;
        }
        return super.onTouchEvent(event);
    }

    public void setOnPPCheckBoxChangeLisener(onPPCheckBoxChangeListener monPPCheckBoxChangeListener) {
        this.monPPCheckBoxChangeListener = monPPCheckBoxChangeListener;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
        postInvalidate();
        if (monPPCheckBoxChangeListener != null) {
            monPPCheckBoxChangeListener.onChange(isChecked);
        }
    }

    public void toggle() {
        if(isChecked){
            setChecked(false);
        }else{
            setChecked(true);
        }
    }

    public interface onPPCheckBoxChangeListener {
        void onChange(boolean isChecked);
    }

    @Override
    public void setEnabled(boolean enabled) {
        this.isEnable = enabled;
        super.setEnabled(enabled);
    }
}
