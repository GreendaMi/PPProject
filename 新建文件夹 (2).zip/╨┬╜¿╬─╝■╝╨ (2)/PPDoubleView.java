package com.allrun.arsmartelevatorformanager.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.ViewGroup;

import com.allrun.arsmartelevatorformanager.R;
import com.allrun.arsmartelevatorformanager.util.DPUnitUtil;

/**
 * 两个卡片切换效果
 * Created by zhaopy on 2017/3/31.
 */

public class PPDoubleView extends ViewGroup {
    Context mContext;
    int padding = 0;
    //底部指示器的高度
    int indicatorH = 100;

    int x = 0;
    int mXDown = 0;
    int mLastX = 0;
    int state = 0;
    int page = 0;//当前页

    //未显示的视图，上下边缩放距离
    int scalH = 50;

    //最短滑动距离
    int a = 0;

    Paint mPaint;
    int animStep = 30;
    boolean isMoving = false;//滑动时屏蔽手势

    public PPDoubleView(Context context) {
        super(context);
    }

    public PPDoubleView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        padding = DPUnitUtil.dip2px(context, 40);
        indicatorH = DPUnitUtil.dip2px(context, 35);
        scalH = DPUnitUtil.dip2px(context, 30);
        a = DPUnitUtil.px2dip(context, ViewConfiguration.get(context).getScaledDoubleTapSlop());
        setClickable(true);
    }

    public PPDoubleView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        getChildAt(0).measure(widthMeasureSpec - padding / 2, heightMeasureSpec - indicatorH);
        getChildAt(1).measure(widthMeasureSpec - padding / 2, heightMeasureSpec - indicatorH);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {

        //计算上下边距缩放距离
        float scale0 = 0.95f + 0.05f * (0 - x) / (getWidth() - padding);
        float scale1 = 0.95f + 0.05f * (x + getWidth() - padding) / (getWidth() - padding);

        getChildAt(0).layout(x, 0, x + getWidth() - padding / 2, getHeight() - indicatorH);
        getChildAt(1).layout(x + getWidth() - padding / 2, 0, x + 2 * getWidth() - padding, getHeight() - indicatorH);
        getChildAt(0).setScaleY(scale1);
        getChildAt(0).setScaleX(scale1);
        getChildAt(1).setScaleY(scale0);
        getChildAt(1).setScaleX(scale0);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);


        if (state == MotionEvent.ACTION_MOVE) {
            if (page == 0) {
                x = -mXDown + mLastX;
            } else {
                x = -getWidth() + padding - mXDown + mLastX;
            }

            //防止过度滑动
            if (x > 0) {
                x = 0;
            }
            if (x < -getWidth() + padding) {
                x = -getWidth() + padding;
            }
            requestLayout();
        } else if (state == MotionEvent.ACTION_UP) {
            //page 0->1
            if (page == 0) {
                //达到了滑动距离，松开手指移动到第二页
                if (x < -getWidth() / 4) {
                    //动画
                    if (x > -getWidth() + padding) {
                        x = x - animStep;
                        isMoving = true;
                    } else {
                        x = -getWidth() + padding;
                        page = 1;
                        isMoving = false;
                    }

                } else {
                    //未达到了滑动距离，松开手指移回到第一页初始位置
                    x = x + animStep;
                    isMoving = true;
                    if (x > 0) {
                        x = 0;
                        isMoving = false;
                    }
                }

            } else {
                //page 1->0
                //达到了滑动距离，松开手指移动到第一页
                if (x > -2 * getWidth() / 3) {
                    x = x + animStep;
                    isMoving = true;
                    if (x > 0) {
                        x = 0;
                        page = 0;
                        isMoving = false;
                    }

                } else {
                    //未达到滑动距离，松开手指回到第二页
                    x = x - animStep;
                    isMoving = true;
                    if (x < -getWidth() + padding) {
                        x = -getWidth() + padding;
                        isMoving = false;
                    }
                }

            }

            //动画结束，下次不再绘制
            if (x == 0 || x == -getWidth() + padding * 3 / 4) {
                state = MotionEvent.ACTION_DOWN;
                isMoving = false;
            }
            requestLayout();
        }

        //画指示器
        if (page == 0) {
            mPaint.setColor(mContext.getResources().getColor(R.color.colorPrimary));
            canvas.drawCircle(getWidth() / 2 - 0.2f * indicatorH, getHeight() - indicatorH / 2, indicatorH * 0.12f, mPaint);

            mPaint.setColor(mContext.getResources().getColor(R.color.color5));
            canvas.drawCircle(getWidth() / 2 + 0.2f * indicatorH, getHeight() - indicatorH / 2, indicatorH * 0.1f, mPaint);
        } else {
            mPaint.setColor(mContext.getResources().getColor(R.color.color5));
            canvas.drawCircle(getWidth() / 2 - 0.2f * indicatorH, getHeight() - indicatorH / 2, indicatorH * 0.1f, mPaint);

            mPaint.setColor(mContext.getResources().getColor(R.color.colorPrimary));
            canvas.drawCircle(getWidth() / 2 + 0.2f * indicatorH, getHeight() - indicatorH / 2, indicatorH * 0.12f, mPaint);
        }

    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        final int action = event.getAction();
        if (isMoving) {
            return super.dispatchTouchEvent(event);
        }
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                state = MotionEvent.ACTION_DOWN;
                // 按下
                mXDown = (int) event.getRawX();
                break;

            case MotionEvent.ACTION_MOVE:

                // 移动
                mLastX = (int) event.getRawX();
                if(Math.abs(mLastX - mXDown) > a){
                    state = MotionEvent.ACTION_MOVE;
                    postInvalidate();
                }

                break;

            case MotionEvent.ACTION_UP:
                state = MotionEvent.ACTION_UP;
                // 抬起
                postInvalidate();
                break;
            default:
                break;
        }
        return super.dispatchTouchEvent(event);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent event) {
        //移动后屏蔽子view的点击事件
        if(state == MotionEvent.ACTION_MOVE && event.getAction() == MotionEvent.ACTION_MOVE){
            return true;
        }
        return super.onInterceptTouchEvent(event);
    }
}
